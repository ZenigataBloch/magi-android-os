import asyncio
import threading
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.metrics import dp
from kivy.properties import ListProperty, NumericProperty, StringProperty
from kivy.utils import platform

from core.controller import run_magi
from core.debug import dbg
from core.magi import create_magi_agents
from ui.boot_kivy import MAGIBootKivy
from ui.magi_map_kivy import MagiMapKivy  # noqa: F401  (registra il widget per il KV)
from ui.nerv_widgets import (  # noqa: F401  (registrano i widget per il KV)
    BoxLabel,
    DiamondTitle,
    JpTag,
    NervPanel,
    SegBar,
)

BASE_DIR = Path(__file__).resolve().parent.parent
FONTS = BASE_DIR / "fonts"

LabelBase.register(
    name="HelveticaNeueCondensed",
    fn_regular=str(FONTS / "HelveticaNeueCondensed.ttf"),
)

LabelBase.register(
    name="Times",
    fn_regular=str(FONTS / "times.ttf"),
)

# font giapponese ridotto ai soli caratteri usati (vedi pyftsubset)
_JP = FONTS / "NotoSerifJP-Bold-sub.otf"
if _JP.exists():
    LabelBase.register(name="NotoSerifJP", fn_regular=str(_JP))
else:
    # senza il file l'app non deve crashare: i kanji appariranno come quadratini
    dbg("FONT GIAPPONESE MANCANTE:", _JP)
    LabelBase.register(
        name="NotoSerifJP",
        fn_regular=str(FONTS / "HelveticaNeueCondensed.ttf"),
    )

dbg("FONT REGISTERED")


KV = """
#:import spaced ui.nerv_widgets.spaced
#:set ORANGE (1, 0.416, 0, 1)
#:set AMBER (1, 0.69, 0, 1)
#:set GREEN (0.24, 1, 0.54, 1)

<Label>:
    font_name: "HelveticaNeueCondensed"

<NervButton@Button>:
    background_normal: ""
    background_down: ""
    background_color: (1, 0.416, 0, 0.35) if self.state == "down" else (1, 0.416, 0, 0.10)
    color: ORANGE
    font_size: sp(16)
    canvas.after:
        Color:
            rgba: 1, 0.416, 0, 0.9
        Line:
            rectangle: self.x, self.y, self.width, self.height
            width: 1

<NervInput@TextInput>:
    background_normal: ""
    background_active: ""
    background_color: 0.02, 0.014, 0, 1
    foreground_color: 1, 0.75, 0.3, 1
    hint_text_color: 1, 0.416, 0, 0.45
    cursor_color: 1, 0.416, 0, 1
    selection_color: 1, 0.416, 0, 0.3
    font_name: "HelveticaNeueCondensed"
    font_size: sp(16)
    multiline: False
    write_tab: False
    padding: [dp(10), dp(14), dp(10), dp(14)]
    canvas.after:
        Color:
            rgba: 1, 0.416, 0, 0.55
        Line:
            rectangle: self.x, self.y, self.width, self.height
            width: 1

FloatLayout:
    canvas.before:
        Color:
            rgba: 0, 0, 0, 1
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        orientation: "vertical"
        padding: [dp(10), app.inset_top + dp(6), dp(10), app.inset_bottom + dp(8)]
        spacing: dp(6)

        # ---- intestazione: 質問 / codice / 解決 / 情報 ----
        BoxLayout:
            size_hint_y: None
            height: dp(56)
            spacing: dp(6)

            JpTag:
                text: "質問"
                size_hint_x: None
                width: dp(74)

            BoxLayout:
                orientation: "vertical"
                padding: [dp(2), dp(4)]

                Label:
                    text: "CODE : 473"
                    font_size: sp(17)
                    color: ORANGE
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    size_hint_y: 0.4

                Label:
                    text: "FILE:MAGI_SYS\\nEX_MODE:ON\\nPRIORITY:AAA"
                    font_size: sp(8)
                    color: 1, 0.416, 0, 0.85
                    halign: "left"
                    valign: "top"
                    text_size: self.size
                    size_hint_y: 0.6

            JpTag:
                text: "解決"
                size_hint_x: None
                width: dp(74)

            BoxLabel:
                text: "情報"
                font_name: "NotoSerifJP"
                font_size: sp(15)
                color: 0.35, 0.78, 0.95, 1
                size_hint: None, None
                size: dp(44), dp(40)
                pos_hint: {"center_y": 0.5}

        # ---- mappa dei tre nodi MAGI ----
        MagiMapKivy:
            id: magi_map
            size_hint_y: None
            height: self.width * 0.8

        # ---- sincronizzazione e consenso ----
        BoxLayout:
            size_hint_y: None
            height: dp(58)
            spacing: dp(10)

            BoxLayout:
                orientation: "vertical"
                spacing: dp(3)

                DiamondTitle:
                    text: spaced("SYNCHRONIZATION")
                    size_hint_y: None
                    height: dp(16)

                SegBar:
                    size_hint_y: None
                    height: dp(18)
                    value: app.sync_value

                Label:
                    text: app.sync_text
                    font_size: sp(10)
                    color: 1, 0.416, 0, 0.85

            BoxLayout:
                orientation: "vertical"
                spacing: dp(3)

                DiamondTitle:
                    text: spaced("CONSENSUS")
                    size_hint_y: None
                    height: dp(16)

                SegBar:
                    size_hint_y: None
                    height: dp(18)
                    value: app.consensus_value
                    color: (0.24, 1, 0.54, 1) if app.consensus_value >= 0.999 else (1, 0.416, 0, 1)

                Label:
                    text: app.consensus_text
                    font_size: sp(10)
                    color: 0.9, 0.9, 0.9, 1

        # ---- decisione finale ----
        BoxLayout:
            orientation: "vertical"
            size_hint_y: None
            height: dp(62)

            DiamondTitle:
                text: spaced("FINAL MAGI DECISION")
                size_hint_y: None
                height: dp(16)

            Label:
                text: app.final_text
                font_size: sp(22)
                color: app.final_color
                shorten: True
                shorten_from: "right"
                text_size: self.width, None

            Label:
                text: app.final_sub
                font_name: "Times"
                font_size: sp(11)
                color: 0.6, 0.6, 0.6, 1
                size_hint_y: None
                height: dp(14)

        # ---- matrice dei voti / risultato ----
        DiamondTitle:
            text: spaced("MAGI VOTING MATRIX")
            size_hint_y: None
            height: dp(16)

        NervPanel:
            padding: dp(8)

            ScrollView:
                do_scroll_x: False
                do_scroll_y: True
                bar_width: dp(4)
                bar_color: 1, 0.416, 0, 0.8
                bar_inactive_color: 1, 0.416, 0, 0.3
                scroll_type: ["bars", "content"]

                Label:
                    text: app.result
                    markup: True
                    font_size: sp(15)
                    size_hint_y: None
                    height: self.texture_size[1]
                    text_size: self.width, None
                    halign: "left"
                    valign: "top"
                    color: 0.85, 0.85, 0.85, 1

        # ---- input e pulsante ----
        BoxLayout:
            size_hint_y: None
            height: dp(46)
            spacing: dp(6)

            NervInput:
                id: prompt
                hint_text: "Inserisci richiesta MAGI..."
                on_text_validate: app.analyze(self.text)

            NervButton:
                text: "ANALYZE"
                size_hint_x: None
                width: dp(98)
                on_release: app.analyze(prompt.text)
"""


def _vote_text(payload, revised=False):
    """Testo del voto per la mappa, come nella GUI desktop."""

    label = payload.get("label", "")
    conf = payload["confidence"]

    if revised and payload.get("changed"):
        return (
            f"{payload['previous']} > {payload['choice']} "
            f"\u00b7 {label} \u00b7 {conf:.0f}%"
        )

    return f"{payload['choice']} \u00b7 {label} \u00b7 {conf:.0f}%"


def _system_insets():
    """(alto, basso) in pixel delle barre di sistema di Android.

    Ritorna (0, 0) fuori da Android e None se Android non e' ancora pronto.
    """

    if platform != "android":
        return 0, 0

    try:
        from jnius import autoclass

        activity = autoclass("org.kivy.android.PythonActivity").mActivity
        insets = activity.getWindow().getDecorView().getRootWindowInsets()

        if insets is None:
            return None

        sdk = autoclass("android.os.Build$VERSION").SDK_INT

        if sdk >= 30:
            kind = autoclass("android.view.WindowInsets$Type")
            bars = insets.getInsets(kind.systemBars() | kind.displayCutout())
            return int(bars.top), int(bars.bottom)

        return (
            int(insets.getSystemWindowInsetTop()),
            int(insets.getSystemWindowInsetBottom()),
        )

    except Exception as e:
        dbg("INSETS ERROR:", e)
        return None


GREEN = [0.24, 1, 0.54, 1]
RED = [1, 0.2, 0.2, 1]


class MAGIMobile(App):

    result = StringProperty("")

    # barre di sistema (px) e indicatori
    inset_top = NumericProperty(0)
    inset_bottom = NumericProperty(0)

    sync_value = NumericProperty(0)
    sync_text = StringProperty("SYNCHRONIZATION RATE: 0%")
    consensus_value = NumericProperty(0)
    consensus_text = StringProperty("WAITING FOR DECISION...")
    final_text = StringProperty("WAITING...")
    final_sub = StringProperty("READY")
    final_color = ListProperty(GREEN)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.busy = False
        self._answered = set()
        self._boot = None
        self._inset_tries = 0

    def build(self):
        self.title = "MAGI-OS | NERV Decision Support System"
        Window.clearcolor = (0, 0, 0, 1)

        try:
            # la tastiera spinge su l'interfaccia invece di coprire il campo
            Window.softinput_mode = "below_target"
        except Exception:
            pass

        return Builder.load_string(KV)

    def on_start(self):
        self._refresh_insets()

        # la schermata di avvio sta sopra l'interfaccia e si toglie da sola
        try:
            self._boot = MAGIBootKivy(
                inset_top=self.inset_top,
                inset_bottom=self.inset_bottom,
                size_hint=(1, 1),
            )
            self.root.add_widget(self._boot)
        except Exception as e:
            dbg("BOOT ERROR:", e)
            self._boot = None

    def on_pause(self):
        # evita che Android chiuda l'app mentre i core stanno rispondendo
        return True

    # ---------- barre di sistema ----------

    def _refresh_insets(self, *_):
        self._inset_tries += 1
        found = _system_insets()

        if found is None:
            if self._inset_tries < 12:
                Clock.schedule_once(self._refresh_insets, 0.3)
            else:
                self._apply_insets(dp(28), dp(44))
            return

        self._apply_insets(*found)

    def _apply_insets(self, top, bottom):
        self.inset_top = top
        self.inset_bottom = bottom

        if self._boot is not None:
            self._boot.inset_top = top
            self._boot.inset_bottom = bottom

        dbg("INSETS:", top, bottom)

    # ---------- eventi dal controller (thread) -> interfaccia ----------

    def handle_event(self, kind, payload):
        """Chiamato sul thread di Kivy."""

        magi_map = self.root.ids.magi_map

        if kind == "options":
            magi_map.set_caption("ROUND 1")

        elif kind == "agent_result":
            if payload.get("valid", True):
                magi_map.set_vote(payload["agent"], _vote_text(payload))
            else:
                magi_map.set_vote(payload["agent"], "ERROR")

            self._answered.add(payload.get("agent"))
            self.sync_value = min(1.0, len(self._answered) / 3.0)
            self.sync_text = f"SYNCHRONIZATION RATE: {self.sync_value * 100:.0f}%"

        elif kind == "round":
            magi_map.set_caption(
                f"ROUND {payload['n']}",
                f"ADV: {payload['advocate']}"
            )
            self.consensus_text = f"ROUND {payload['n']} IN PROGRESS..."

        elif kind == "revision":
            if not payload.get("carried"):
                magi_map.set_vote(
                    payload["agent"],
                    _vote_text(payload, revised=True)
                )

    # ---------- risultato finale ----------

    def format_votes(self, votes):

        return "\n".join(
            f"\u2022 {choice.upper()}: {value}"
            for choice, value in votes.items()
        )

    def show_result(self, result):

        self.busy = False

        if not isinstance(result, dict):
            self.result = str(result)
            self.final_text = "DONE"
            return

        responses = result.get("responses", [])
        decision = result.get("decision", {})

        votes = decision.get("votes", {})
        winner = decision.get("choice", "UNKNOWN")
        consensus = decision.get("consensus", 0)
        verdict = decision.get("verdict", "")

        self.root.ids.magi_map.set_caption(verdict)

        # indicatori
        try:
            self.consensus_value = max(0.0, min(1.0, float(consensus) / 100.0))
        except (TypeError, ValueError):
            self.consensus_value = 0
        self.consensus_text = f"CONSENSUS: {consensus}%"
        self.final_text = str(winner).upper()
        self.final_sub = str(verdict)
        self.final_color = GREEN

        text = (
            "[color=#ff8c00][b][ MAGI SYSTEM ONLINE ][/b][/color]\n\n"
            "[color=#ffffff][b]FINAL DECISION[/b][/color]\n\n"
            f"[color=#3fd17a][b]>> {winner.upper()}  ({verdict})[/b][/color]\n\n"
            f"[color=#3fd17a]CONSENSUS: {consensus}%[/color]\n\n"
        )

        if decision.get("rounds") == 2:
            r1 = decision.get("round1", {})
            text += (
                "[color=#aaaaaa]"
                f"ROUND 1: {r1.get('verdict')} ({r1.get('tally')})  >  "
                f"ROUND 2: {verdict} ({decision.get('tally')})"
                "[/color]\n"
            )
            if decision.get("flips"):
                text += (
                    "[color=#aaaaaa]CHANGED VOTE: "
                    + ", ".join(decision["flips"])
                    + "[/color]\n"
                )
            text += "\n"

        text += (
            "[color=#aaaaaa]VOTING ANALYSIS[/color]\n"
            f"{self.format_votes(votes)}\n\n"
            "--------------------\n\n"
            "[color=#ff8c00][b]INDIVIDUAL CORES[/b][/color]\n\n"
        )

        colors = {
            "MELCHIOR": "#00ffff",
            "BALTHASAR": "#ffaa00",
            "CASPER": "#ff55ff",
        }

        for response in responses:

            agent = response.get("agent", "UNKNOWN").upper()
            color = next(
                (c for name, c in colors.items() if name in agent),
                "#ffffff"
            )
            choice = str(
                response.get("label") or response.get("choice")
            ).upper()

            text += (
                f"[color={color}][b][ {agent} ][/b][/color]\n"
                "[color=#777777]--------------------[/color]\n\n"
                f"[color=#ffffff][b]CHOICE:[/b][/color] "
                f"[color=#3fd17a]{choice}[/color]\n"
                f"[color=#ffffff][b]CONFIDENCE:[/b][/color] "
                f"{response.get('confidence')}%\n\n"
                f"[color=#cccccc]{response.get('reasoning')}[/color]\n\n"
                "[color=#555555]--------------------[/color]\n\n"
            )

        self.result = text

    def show_error(self, message):

        self.busy = False
        self.final_text = "ERROR"
        self.final_sub = str(message)[:80]
        self.final_color = RED
        self.consensus_text = "NO DECISION"
        self.result = f"[color=#ff3333]ERRORE: {message}[/color]"

    # ---------- avvio richiesta ----------

    def analyze(self, prompt):

        prompt = prompt.strip()

        if self.busy:
            return

        if not prompt:
            self.result = "Inserisci una richiesta"
            return

        self.busy = True
        self.result = "MAGI ANALYZING..."

        # svuota il campo: la richiesta e' gia' stata copiata in `prompt`
        self.root.ids.prompt.text = ""

        # azzera gli indicatori
        self._answered = set()
        self.sync_value = 0
        self.sync_text = "SYNCHRONIZATION RATE: 0%"
        self.consensus_value = 0
        self.consensus_text = "ANALYZING..."
        self.final_text = "ANALYZING..."
        self.final_sub = "PLEASE WAIT"
        self.final_color = GREEN

        magi_map = self.root.ids.magi_map
        magi_map.reset()

        def worker():

            agents = create_magi_agents()

            def status_update(name, status):
                Clock.schedule_once(
                    lambda dt: magi_map.set_status(name.upper(), status)
                )

            def on_event(kind, payload):
                Clock.schedule_once(
                    lambda dt: self.handle_event(kind, payload)
                )

            try:
                result = asyncio.run(
                    run_magi(
                        prompt,
                        agents,
                        status_callback=status_update,
                        event_callback=on_event
                    )
                )
            except Exception as e:
                Clock.schedule_once(lambda dt: self.show_error(str(e)))
                return

            Clock.schedule_once(lambda dt: self.show_result(result))

        threading.Thread(target=worker, daemon=True).start()
