import json
import os
from datetime import datetime


MEMORY_FILE = "data/decisions.json"


def save_decision(prompt, decision):

    os.makedirs(
        "data",
        exist_ok=True
    )

    entry = {
        "timestamp": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),
        "prompt": prompt,
        "choice": decision.get(
            "choice",
            "UNKNOWN"
        ),

        "consensus": decision.get(
            "consensus",
            0
        ),

        "votes": decision.get(
            "votes",
            {}
        )
    }


    history = load_history()

    history.append(
        entry
    )


    with open(
        MEMORY_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            history,
            f,
            indent=4,
            ensure_ascii=False
        )


def load_history():

    if not os.path.exists(
        MEMORY_FILE
    ):
        return []


    with open(
        MEMORY_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)