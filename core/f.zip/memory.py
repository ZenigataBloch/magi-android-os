import json
import os
from datetime import datetime
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
MEMORY_FILE = DATA_DIR / "decisions.json"

# campi del verdetto da conservare, se presenti
EXTRA_KEYS = (
    "verdict",
    "tally",
    "rounds",
    "round1",
    "advocate",
    "objection",
    "flips",
    "dissent",
    "errors",
    "tiebreak",
    "note",
)

CORE_KEYS = (
    "agent",
    "choice",
    "label",
    "confidence",
    "reasoning",
    "previous",
    "changed",
    "valid",
)


def save_decision(prompt, decision, results=None):
    """results = il dict restituito da run_magi (opzionale, aggiunge
    opzioni e analisi per singolo core)."""

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prompt": prompt,
        "choice": decision.get("choice", "UNKNOWN"),
        "consensus": decision.get("consensus", 0),
        "votes": decision.get("votes", {}),
    }

    for key in EXTRA_KEYS:
        if key in decision:
            entry[key] = decision[key]

    if results:
        entry["options"] = results.get("options", [])

        entry["cores"] = [
            {k: r[k] for k in CORE_KEYS if k in r}
            for r in results.get("responses", [])
        ]

    history = load_history()
    history.append(entry)

    # scrittura atomica: prima un file temporaneo, poi lo si sostituisce
    tmp = MEMORY_FILE.with_suffix(".tmp")

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=4, ensure_ascii=False)

    os.replace(tmp, MEMORY_FILE)


def load_history():

    if not MEMORY_FILE.exists():
        return []

    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        return data if isinstance(data, list) else []

    except json.JSONDecodeError:
        # file rovinato: lo metto da parte invece di perderlo
        os.replace(MEMORY_FILE, MEMORY_FILE.with_suffix(".corrupt"))
        return []